//done
#include <iostream>
#include <algorithm>
#include <sstream>
#include <string>
#include <random>
#include <iomanip>
#include "sprite.h"
#include "player.h"
#include "gameData.h"
#include "engine.h"
#include "frameGenerator.h"
#include "bulletPool.h"
#include "chunk.h"


Engine::~Engine()
{
  delete player;
  for ( Drawable* sprite : sprites ) {
    delete sprite;
  }
  for ( CollisionStrategy* strategy : strategies ) {
    delete strategy;
  }
  delete bPool;
  std::cout << "Terminating program" << std::endl;
}

Engine::Engine() :
  rc( RenderContext::getInstance() ),
  io( IoMod::getInstance() ),
  clock( Clock::getInstance() ),
  renderer( rc.getRenderer() ),
  world("back", Gamedata::getInstance().getXmlInt("back/factor") ),
  mounts("mounts", Gamedata::getInstance().getXmlInt("mounts/factor") ),
  trees("trees", Gamedata::getInstance().getXmlInt("trees/factor") ),
  viewport( Viewport::getInstance() ),
  hud(Hud::getInstance()),
  bigDone(false),
  viewHud(false),
  godMode(false),
  lives(3),
  player(new Player("Player")),
  platform(new Sprite("Platform")),
  finishStar(new Sprite("finishStar")),
  bPool(new BulletPool("bullet")),
  sprites(),  // star is scaled in the XML
  strategies(),
  currentSprite(0),
  currentStrategy(0),
  collision(false),
  makeVideo( false )
{
  int n = Gamedata::getInstance().getXmlInt("numberOfCats");
  sprites.reserve(n);
  Vector2f pos = player->getPosition();
  int w = player->getScaledWidth();
  int h = player->getScaledHeight();
  for (int i = 0; i < n; ++i) {
    sprites.push_back( new SmartSprite("YellowStar", pos, w, h) );
    sprites[i]->setX(rand()%2000);
    sprites[i]->setY(rand()%500);
    player->attach( sprites[i] );
  }

  strategies.push_back( new RectangularCollisionStrategy );
  strategies.push_back( new PerPixelCollisionStrategy );
  strategies.push_back( new MidPointCollisionStrategy );

  Viewport::getInstance().setObjectToTrack(player);
  std::cout << "Loading complete" << std::endl;
}

void Engine::draw() const {
  world.draw();
  mounts.draw();

  SDL_Rect r;
	r.x = 0;
	r.y = 420;
	r.w = 2000;
	r.h = 80;
	SDL_SetRenderDrawColor(renderer, 11, 105, 32, 255);
	SDL_RenderFillRect(renderer, &r);

  trees.draw();



  for ( const Drawable* sprite : sprites )
  {
    sprite->draw();
  }

  strategies[currentStrategy]->draw();
  if ( collision ) {
    io.writeText("You Have Perished", 500, 250);
  }

  player->draw();
  platform->draw();
  finishStar->draw();
  bPool->draw();

  SDL_Color textColor = {255, 255, 0, 0};
  if(bigDone)
  {
    std::stringstream finish;
    finish << "Congratulations!!";
    io.writeText(finish.str(), 500, 250, textColor);
  }
  if(viewHud)
  {
    hud.drawHud();
  }
  else
  {
    std::stringstream hudTemp;
    hudTemp << "Toggle HUD with F1";
    io.writeText(hudTemp.str(), Gamedata::getInstance().getXmlInt("view/width")-220, 10, textColor);
  }

  if(godMode) {
    std::stringstream godActive;
    godActive << "God mode active!";
    io.writeText(godActive.str(), 30, 90, textColor);
  }

  std::stringstream life;
  life << "Lives: " << lives;

  if(lives == 0)
  {
    clock.pause();

    std::stringstream reset;
    reset << "Reset game [R]";

    io.writeText(reset.str(), Gamedata::getInstance().getXmlInt("view/width")/2-60,
                 Gamedata::getInstance().getXmlInt("view/height")/2-40, textColor);
  }

  io.writeText(life.str(), 30, 60, textColor);
  std::stringstream s;
  s << "Sean Upshaw";
  io.writeText(s.str(), 0, (Gamedata::getInstance().getXmlInt("view/height")-Gamedata::getInstance().getXmlInt("font/size")-5), textColor);

  viewport.draw();
  SDL_RenderPresent(renderer);
}

void Engine::checkForCollisions() {
  auto it = sprites.begin();
  while ( it != sprites.end() ) {
    if ( strategies[currentStrategy]->execute(*player, **it) ) {
      SmartSprite* doa = *it;
      player->detach(doa);
      delete doa;
      it = sprites.erase(it);
    }
    else ++it;
  }
}

void Engine::update(Uint32 ticks) {
  if((player->getX() == finishStar->getX()) && (player->getY() == finishStar->getY()))
  {
    bigDone = true;
  }
  for(auto sprite : sprites)
  {
    if(bPool->collidedWith(sprite))
    {
      sprite->explode();
      sprite->setX(rand()%2000);
      sprite->setY(rand()%500);
    }
  }

  for(auto sprite : sprites)
  {
    if(!godMode && strategies[currentStrategy]->execute(*player, *sprite))
    {
      sprite->explode();
      player->explode();
      srand(time(NULL));
      sprite->setX(rand()%2000);
      sprite->setY(rand()%500);
      lives--;
    }
  }
  platform->update(ticks);
  finishStar->update(ticks);
  bPool->update(ticks);
  player->update(ticks);
  for(Drawable* sprite : sprites)
  {
    sprite->update(ticks);
  }
  world.update();
  mounts.update();
  trees.update();
  viewport.update(); // always update viewport last
}

void Engine::switchSprite(){
  ++currentSprite;
  currentSprite = currentSprite % 2;
  if ( currentSprite ) {
    Viewport::getInstance().setObjectToTrack(player);
  }
  else {
    Viewport::getInstance().setObjectToTrack(sprites[currentSprite]);
  }
}

void Engine::toggleGod()
{
  if (godMode)
  {
    godMode = false;
  }
  else if (!godMode)
  {
    godMode = true;
  }
}

void Engine::toggleHud()
{
  if(viewHud)
  {
    viewHud = false;
  }
  else if(!viewHud)
  {
    viewHud = true;
  }
}

bool Engine::play() {
  SDL_Event event;
  const Uint8* keystate;
  bool done = false;
  Uint32 ticks = clock.getElapsedTicks();
  FrameGenerator frameGen;

  while ( !done ) {
    // The next loop polls for events, guarding against key bounce:
    while ( SDL_PollEvent(&event) ) {
      keystate = SDL_GetKeyboardState(NULL);
      if (event.type ==  SDL_QUIT) { done = true; break; }
      if(event.type == SDL_KEYDOWN) {
        if (keystate[SDL_SCANCODE_ESCAPE] || keystate[SDL_SCANCODE_Q]) {
          done = true;
          break;
        }
        if ( keystate[SDL_SCANCODE_P] ) {
          if ( clock.isPaused() ) clock.unpause();
          else clock.pause();
        }
        if(keystate[SDL_SCANCODE_M])
        {
          currentStrategy = (1 + currentStrategy) % strategies.size();
        }
        if ( keystate[SDL_SCANCODE_T] ) {
          switchSprite();
        }
        if ( keystate[SDL_SCANCODE_F1] )
        {
          toggleHud();
        }
        if( keystate[SDL_SCANCODE_G])
        {
          toggleGod();
        }
        if( keystate[SDL_SCANCODE_R])
        {
          std::cout << "Resetting game" << std::endl;
          clock.unpause();
          return true;
        }
        if (keystate[SDL_SCANCODE_F4] && !makeVideo) {
          std::cout << "Initiating frame capture" << std::endl;
          makeVideo = true;
        }
        else if (keystate[SDL_SCANCODE_F4] && makeVideo) {
          std::cout << "Terminating frame capture" << std::endl;
          makeVideo = false;
        }
      }
    }

    // In this section of the event loop we allow key bounce:

    ticks = clock.getElapsedTicks();
    if ( ticks > 0 ) {
      clock.incrFrame();
      if (keystate[SDL_SCANCODE_A]) {
        static_cast<Player*>(player)->left();
      }
      if (keystate[SDL_SCANCODE_D]) {
        static_cast<Player*>(player)->right();
      }
      if (keystate[SDL_SCANCODE_W]) {
        static_cast<Player*>(player)->up();
      }
      if (keystate[SDL_SCANCODE_S]) {
        static_cast<Player*>(player)->down();
      }
      if(keystate[SDL_SCANCODE_SPACE] && player->getVelocityX() > 0)
      {
        bPool->shoot(Vector2f(player->getX(), 700),
                     Vector2f(1000, player->getVelocityY()));
      }
      if(keystate[SDL_SCANCODE_SPACE] && player->getVelocityX() < 0)
      {
        bPool->shoot(Vector2f(player->getX(), 700),
                     Vector2f(-1000, player->getVelocityY()));
      }
      draw();
      update(ticks);
      if ( makeVideo ) {
        frameGen.makeFrame();
      }
    }
  }
  return false;
}
