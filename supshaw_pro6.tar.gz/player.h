#ifndef PLAYER__H
#define PLAYER__H

#include "bulletPool.h"
#include "smartSprite.h"
#include "subjectSprite.h"
#include "explodingSprite.h"

// In this example the player is derived from MultiSprite.
// However, there are many options.
class Player : public Drawable
{
public:
  Player(const std::string&);
  Player(const Player&);
  virtual ~Player()
  {
    if(explosion) delete explosion;
  }

  virtual void draw() const;
  virtual void update(Uint32 ticks);

  virtual const Image* getImage() const
  {
    return images[currentFrame];
  }
  int getScaledWidth() const
  {
    return getScale()*images[currentFrame]->getWidth();
  }
  int getScaledHeight() const
  {
    return getScale()*images[currentFrame]->getHeight();
  }

  virtual const SDL_Surface* getSurface() const
  {
    return images[currentFrame]->getSurface();
  }

  void collided() { collision = true; }
  void missed() { collision = false; }
  Player& operator=(const Player&);

  void attach( SmartSprite* o ) { observers.push_back(o); }
  void detach( SmartSprite* o );
  void right();
  void left();
  void up();
  void down();
  void stop();
  virtual void explode();

private:
  std::vector<Image *> images;
  std::vector<Image *> imagesRight;
  std::vector<Image *> imagesLeft;
  std::vector<Image *> imagesStopped;

  unsigned currentFrame;
  unsigned numberOfFrames;
  unsigned frameInterval;
  float timeSinceLastFrame;
  int worldWidth;
  int worldHeight;

  ExplodingSprite* explosion;

  bool collision;
  Vector2f initialVelocity;

  void advanceFrame(Uint32 ticks);

protected:
  std::list<SmartSprite*> observers;
};
#endif
