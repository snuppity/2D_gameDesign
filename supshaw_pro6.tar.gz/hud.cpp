#include <SDL.h>
#include <SDL_image.h>
#include <sstream>
#include "hud.h"
#include "gameData.h"
#include "renderContext.h"

Hud& Hud::getInstance()
{
  static Hud instance;
  return instance;
}

Hud::~Hud()
{
  TTF_CloseFont(font);
  TTF_Quit();
}

Hud::Hud() :
  init(TTF_Init()),
  x(Gamedata::getInstance().getXmlInt("hud/x")),
  y(Gamedata::getInstance().getXmlInt("hud/y")),
  w(Gamedata::getInstance().getXmlInt("hud/w")),
  h(Gamedata::getInstance().getXmlInt("hud/h")),
  viewport(Viewport::getInstance()),
  clock(Clock::getInstance()),
  renderer(RenderContext::getInstance().getRenderer()),
  font(TTF_OpenFont(Gamedata::getInstance().getXmlStr("font/file").c_str(),
       Gamedata::getInstance().getXmlInt("font/size"))),
  textColor({255, 255, 0, 0})
{
  if(init == -1)
  {
    throw std::string("Error: couldn't init font");
  }
  if(font == NULL)
  {
    throw std::string("Error: font not found");
  }
  textColor.r = Gamedata::getInstance().getXmlInt("hud/r");
  textColor.g = Gamedata::getInstance().getXmlInt("hud/g");
  textColor.b = Gamedata::getInstance().getXmlInt("hud/b");
  textColor.a = Gamedata::getInstance().getXmlInt("hud/a");
}

void Hud::writeText(const std::string& msg, SDL_Color c, int x, int y) const
{
  int textWidth;
  int textHeight;

  SDL_Surface* surface = TTF_RenderText_Solid(font, msg.c_str(), c);
  SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);

  textWidth = surface->w;
  textHeight = surface->h;
  SDL_FreeSurface(surface);
  SDL_Rect dst = {x, y, textWidth, textHeight};

  SDL_RenderCopy(renderer, texture, NULL, &dst);
  SDL_DestroyTexture(texture);
}


void Hud::drawHud()
{
  int distx = x+5;
  int disty = y+5;

  std::stringstream strm;
  strm << "FPS: " << clock.getFps();
  writeText(strm.str(), textColor, distx, disty);

  std::stringstream strm2;
  if(clock.getSeconds() < 60)
  {
    strm2 << "Time: " << clock.getSeconds() << "s";
  }
  else
  {
    int mins = clock.getSeconds()/60;
    int secs = clock.getSeconds()%60;

    strm2 << "Time: " << mins << "m " << secs << "s";
  }
  writeText(strm2.str(), textColor, distx, disty+25);

  std::stringstream hud;
  hud << "Toggle HUD: F1";
  writeText(hud.str(), textColor, distx, disty+50);

  std::stringstream strat;
  strat << "Change collision strategy: M";
  writeText(strat.str(), textColor, distx, disty+75);

  std::stringstream direct;
  direct << "Left & Right: A & D\n";
  direct << "Jump: W\n";
  writeText(direct.str(), textColor, distx, disty+100);

  SDL_Rect r;
  r.x = x;
  r.y = y;
  r.w = w;
  r.h = h;

  SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
  SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255/3);

  SDL_RenderFillRect(renderer, &r);

  SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255);
  SDL_RenderDrawRect(renderer, &r);
}
