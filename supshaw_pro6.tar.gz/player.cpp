#include <list>
#include <cmath>
#include "player.h"
#include "bulletPool.h"
#include "explodingSprite.h"
#include "gameData.h"
#include "imageFactory.h"
#include "chunk.h"

void Player::advanceFrame(Uint32 ticks)
{
  timeSinceLastFrame += ticks;
  if(timeSinceLastFrame > frameInterval)
  {
    currentFrame = (currentFrame+1) % numberOfFrames;
    timeSinceLastFrame = 0;
  }
}

Player::Player( const std::string& name) :
  Drawable(name,
           Vector2f(Gamedata::getInstance().getXmlInt(name+"/startLoc/x"),
                    Gamedata::getInstance().getXmlInt(name+"/startLoc/y")),
           Vector2f(Gamedata::getInstance().getXmlInt(name+"/speedX"),
                    Gamedata::getInstance().getXmlInt(name+"/speedY")),
           1),
  images( ImageFactory::getInstance().getImages("Player") ),
  imagesRight( ImageFactory::getInstance().getImages("PlayerRight")),
	imagesLeft( ImageFactory::getInstance().getImages("PlayerLeft")),
  imagesStopped(ImageFactory::getInstance().getImages("PlayerStopped")),
  currentFrame(0),
  numberOfFrames( Gamedata::getInstance().getXmlInt("Player/frames") ),
  frameInterval( Gamedata::getInstance().getXmlInt("Player/frameInterval")),
  timeSinceLastFrame( 0 ),
  worldWidth(Gamedata::getInstance().getXmlInt("world/width")),
  worldHeight(Gamedata::getInstance().getXmlInt("world/height")),
	explosion(nullptr),
  collision(false),
  initialVelocity(0),
  observers()
{ }


Player::Player(const Player& s) :
  Drawable(s),
  images(s.images),
  imagesRight(s.imagesRight),
  imagesLeft(s.imagesLeft),
  imagesStopped(s.imagesStopped),
  currentFrame(s.currentFrame),
  numberOfFrames( s.numberOfFrames ),
  frameInterval( s.frameInterval ),
  timeSinceLastFrame( s.timeSinceLastFrame ),
  worldWidth( s.worldWidth ),
  worldHeight( s.worldHeight ),
  explosion(nullptr),
  collision(s.collision),
  initialVelocity(s.getVelocity()),
  observers(s.observers)
  { }

Player& Player::operator=(const Player& s) {
  Drawable::operator=(s);
  images = (s.images);
	imagesRight = (s.imagesRight);
	imagesLeft = (s.imagesLeft);
  imagesStopped = (s.imagesStopped);
  currentFrame = (s.currentFrame);
  numberOfFrames = ( s.numberOfFrames );
  frameInterval = ( s.frameInterval );
  timeSinceLastFrame = ( s.timeSinceLastFrame );
  worldWidth = ( s.worldWidth );
  worldHeight = ( s.worldHeight );
	explosion = ( nullptr );
  collision = s.collision;
  initialVelocity = s.initialVelocity;
  observers = s.observers;
  return *this;
}

void Player::draw() const {
	if ( explosion ) {
		explosion->draw();
	}
  else images[currentFrame]->draw(getX(), getY(), getScale());
}

void Player::stop() {
  //setVelocity( Vector2f(0, 0) );
  setVelocityX( 0.43*getVelocityX() );
  setVelocityY(0);
  images = imagesStopped;
}

void Player::right() {
  if ( getX() < worldWidth-getScaledWidth()) {
    setVelocityX(200);
    images = imagesRight;
  }
}
void Player::left()  {
  if ( getX() > 0) {
    setVelocityX(-200);
    images = imagesLeft;
  }
}
void Player::up()    {
  if ( getY() > 0) {
    setVelocityY( -200 );
  }
}
void Player::down()  {
  if ( getY() < worldHeight-getScaledHeight()) {
    setVelocityY( 200 );
  }
}

void Player::explode() {
	if ( !collision ) {
		Sprite sprite(getName(),getPosition(), getVelocity(), images[0], 1);
    sprite.setScale( getScale() );
		explosion = new ExplodingSprite(sprite);
  }
}

void Player::detach( SmartSprite* o ) {
  std::list<SmartSprite*>::iterator ptr = observers.begin();
  while ( ptr != observers.end() ) {
    if ( *ptr == o ) {
      ptr = observers.erase(ptr);
      return;
    }
    ++ptr;
  }
}

void Player::update(Uint32 ticks) {
  if ( collision )
  {
    explosion->update(ticks);
    if(explosion->chunkCount() == 0)
    {
      delete explosion;
      explosion = nullptr;
    }
    return;
  }

  Vector2f incr = getVelocity() * static_cast<float>(ticks) * .001;
  setPosition(getPosition() + incr);

  std::list<SmartSprite*>::iterator ptr = observers.begin();
  while ( ptr != observers.end() ) {
    int offset = rand()%5;
    offset = offset*(rand()%2?-1:1);
    const Vector2f off(offset, offset);
    (*ptr)->setPlayerPos( getPosition()+off );
    ++ptr;
  }

  if(getVelocityY() < 0)
  {
    setVelocityY(getVelocityY()+(2*ticks));
  }

  if(getY() < 0)
  {
    setVelocityY(fabs(getVelocityY()));
  }
  if ( getY() > worldHeight-getScaledHeight()) {
    setVelocityY( -fabs( getVelocityY() ) );
  }
  if ( getX() < 0) {
    setVelocityX( fabs( getVelocityX() ) );
  }
  if ( getX() > worldWidth-getScaledWidth()) {
    setVelocityX( -fabs( getVelocityX() ) );
  }

  advanceFrame(ticks);
  stop();
}
